package entity;

public class stuWithGrade {
	private String studentNum;
	private String studentNameString;
	private String grade;
	private String classNumber;
	public String getClassNumber() {
		return classNumber;
	}
	public void setClassNumber(String classNumber) {
		this.classNumber = classNumber;
	}
	public String getStudentNum() {
		return studentNum;
	}
	public void setStudentNum(String studentNum) {
		this.studentNum = studentNum;
	}
	public String getStudentNameString() {
		return studentNameString;
	}
	public void setStudentNameString(String studentNameString) {
		this.studentNameString = studentNameString;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
}
