package login;

import java.awt.List;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import javax.servlet.RequestDispatcher;

import org.omg.CORBA.Request;

import entity.ClassNNN;
import entity.Course;
import entity.ElectiveCourse;
import entity.FailByClass;
import entity.Teacher;
import entity.displayByCourse;
import entity.reportCard;
import entity.stuWithGrade;
import entity.teachClassCourse;

public class database {
	PreparedStatement preparedStatement=null;
	ResultSet resultSet=null;
	public Connection getConnection() {
		Connection connection=null;
		String driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url="jdbc:sqlserver://localhost:1433;dataBasename=oa";
		String user="sa";
		String pwd="123456";
		try {
			Class.forName(driver);
			connection=DriverManager.getConnection(url,user,pwd);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	public void closeConn(ResultSet resultSet,java.sql.PreparedStatement statement,Connection connection) {
		try {
			resultSet.close();
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void closeConn(java.sql.PreparedStatement statement,Connection connection) {
		try {
			statement.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//��ѯ���˺��Ƿ��Ѿ�ע��
	public boolean queryByNum (String username,String type) {
		//type���ӵ�ǰ��Ҫ�ӿո�      Sno=���ʺ�ǰ�治Ҫ�пո�
		String sql="";
		if("student".equals(type)) {
			sql="select * from "+type+" where Sno =?";
		}
		if("teacher".equals(type)) {
			sql="select * from "+type+" where Tno =?";
		}
		if("manager".equals(type)) {
			sql="select * from "+type+" where Mno =?";
		}
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
//			preparedStatement.setString(1,type);
			preparedStatement.setString(1,username);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				System.out.println("ѧ������Ϊ"+resultSet.getString(2));
				return true;
			}else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public String queryLogin (String username,String type,String pwd) {
		//type���ӵ�ǰ��Ҫ�ӿո�      Sno=���ʺ�ǰ�治Ҫ�пո�
		String sql="";
		if("student".equals(type)) {
			sql="select Sname from student where Sno =? and Spwd=?";
		}
		if("teacher".equals(type)) {
			sql="select Tname from teacher where Tno =? and pwd=?";
		}
		if("manager".equals(type)) {
			sql="select Mname from manager where Mno =? and Pwd=?";
		}
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,username);
			preparedStatement.setString(2,pwd);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				System.out.println(resultSet.getString(1)+"��½�ɹ�");
				return resultSet.getString(1);
			}else {
				return "null";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "null";
	}
	public String queryStuCou (int semester,String username) {

		String sql="select * from student s join sc b on s.Sno=b.Sno join course c on c.Cno=b.Cno where s.Sno=? and c.semester=?";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,username);
			preparedStatement.setInt(2,semester);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				System.out.println(resultSet.getString(13));
				return resultSet.getString(2);
			}else {
				return "null";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "null";
	}
	public String queryYear (String username,String type) {
		//type���ӵ�ǰ��Ҫ�ӿո�      Sno=���ʺ�ǰ�治Ҫ�пո�
		String sql="select * from "+type+" where Sno =?";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
//			preparedStatement.setString(1,type);
			preparedStatement.setString(1,username);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				System.out.println("��½�ɹ�"+resultSet.getString(7));
				return resultSet.getString(7);
			}else {
				return "null";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "null";
	}
	public String[][] queryStuClass (String username,int semester) {
		String sql="select * from course cou join teachInfo cla on cou.Cno=cla.Cno join teacher tea on tea.Tno=cla.Tno where cou.Cno in(\r\n" + 
				"	select course.Cno from student s join sc b on s.Sno=b.Sno join course  on b.Cno=course.Cno where s.Sno=? and course.Semester=? \r\n" + 
				")";
		Connection connection=getConnection();
		String result[][]=new String[8][5];
		try {
			preparedStatement =connection.prepareStatement(sql);
//			preparedStatement.setString(1,type);
			preparedStatement.setString(1,username);
			preparedStatement.setInt(2, semester);
			resultSet=preparedStatement.executeQuery();
//			if(resultSet.next()) {
			System.out.println("��ѯѧ�����˵Ŀγ̱���½�ɹ�");
			while(resultSet.next()) {
//				System.out.print(resultSet.getString(2)+"-----");
//				System.out.print(resultSet.getString(7)+"-----");
//				System.out.print(resultSet.getString(8)+"-----");
//				System.out.println(resultSet.getString(9)+"-----");
				//��ȡ�����ڼ��͵ڼ��ڿε�һ���������
				String temp=resultSet.getString("classTime");
				//��ȡ��ڿ������ڼ��Ŀ�    "12"   '1'-'0'   '2'-'0'
				int week=temp.charAt(0)-'0';
				//��ȡ��ڿ��ǵڼ��ڿ�
				int period=temp.charAt(1)-'0';
				result[week][period]=resultSet.getString("Cname")+resultSet.getString("classPlace")+resultSet.getString("Tname")+resultSet.getString("remarks");
				//System.out.println("��������"+week+",��"+period+"�ڿΣ���������Ϊ��"+result[week][period]);
			}
			
			return result;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	//��ѯһ��ѧ����ȫ���ɼ�
	public ArrayList<reportCard> queryStuGrade (String username,int semester) {
		String sql="select * from student s join sc b on s.Sno=b.Sno join course c on b.Cno=c.Cno where b.Sno=? and c.Semester=?";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,username);
			preparedStatement.setInt(2, semester);
			resultSet=preparedStatement.executeQuery();
			ArrayList<reportCard> list=new ArrayList<reportCard>();
			while(resultSet.next()) {
				//һ����¼����Ϊһ���ɼ�������
				//Ϊ�ɼ��������ʼ��
				reportCard report=new reportCard();
				report.setCno(resultSet.getString("Cno"));
				report.setCname(resultSet.getString("Cname"));
				report.setCredit(resultSet.getInt("Credit"));
				report.setGrade(resultSet.getInt("grade"));
				//�ѵ�ǰ�ĳɼ����������ӵ������б���
				list.add(report);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	//��ѯһ��ѧ���Ĳ�����ĳɼ�
	public ArrayList<reportCard> queryStuFail (String username,int semester) {
		String sql="select * from student s join sc b on s.Sno=b.Sno join course c on b.Cno=c.Cno where b.Sno=? and c.Semester=? and b.grade<60";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,username);
			preparedStatement.setInt(2, semester);
			resultSet=preparedStatement.executeQuery();
			ArrayList<reportCard> list=new ArrayList<reportCard>();
			while(resultSet.next()) {
				//һ����¼����Ϊһ���ɼ�������
				//Ϊ�ɼ��������ʼ��
				reportCard report=new reportCard();
				report.setCno(resultSet.getString("Cno"));
				report.setCname(resultSet.getString("Cname"));
				report.setCredit(resultSet.getInt("Credit"));
				report.setGrade(resultSet.getInt("grade"));
				//�ѵ�ǰ�ĳɼ����������ӵ������б���
				list.add(report);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public String[][] queryTeacherClass (String username,String term) {
		//������ӣ���ȡ��ǰ��ʦ��ѡ��ѧ�ڽ��ڵĿγ���Ϣ��
		String sql="select * from course c join teachInfo info on c.Cno=info.Cno join class on class.ClassNo=info.ClassNo\r\n" + 
				"where info.term=? and info.Tno=?";
		//��ȡ���ݿ���������
		Connection connection=getConnection();
		//��ʼ������ֵ
		String result[][]=new String[8][5];
		try {
			preparedStatement =connection.prepareStatement(sql);
			//���ò���
			preparedStatement.setString(1, term);
			preparedStatement.setString(2,username);
			//ִ��sql���
			resultSet=preparedStatement.executeQuery();
			System.out.println("��ѯ��ʦ�Ŀγ̱����Ӻ�̨���ݿ�ɹ�");
			//���������
			while(resultSet.next()) {
				//��ȡ�����ڼ��͵ڼ��ڿε�һ���������
				String temp=resultSet.getString("classTime");
				//temp-----"12"
				System.out.println("�Ͽε�ʱ����"+temp);
				//��ȡ��ڿ������ڼ��Ŀ�
				int week=temp.charAt(0)-'0';
				//week-----1
				//��ȡ��ڿ��ǵڼ��ڿ�
				int period=temp.charAt(1)-'0';
				//period---2
				result[week][period]=resultSet.getString("Cname")+resultSet.getString("classPlace")+resultSet.getString("ClassName")+resultSet.getString("remarks");
				System.out.println("��������"+week+",��"+period+"�ڿΣ���������Ϊ��"+result[week][period]);
			}
			//���ض�ά����
			return result;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	//��ѯ��ʦ�����ڵİ༶�γ�
	public ArrayList<teachClassCourse> queryTeachClassCourse (String username) {
		String sql="select * from classCourse where Tno=?";
		Connection connection=getConnection();
		ArrayList<teachClassCourse> list=new ArrayList<teachClassCourse>();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,username);
			resultSet=preparedStatement.executeQuery();
			System.out.println("��ѯ��ʦ���ڵĿγ̺Ϳ�Ŀ�ɹ�");
			while(resultSet.next()) {
				teachClassCourse t=new teachClassCourse();
				t.setClassName(resultSet.getString("ClassName"));
				t.setCourse(resultSet.getString("Cname"));
				t.setClassNo(resultSet.getString("ClassNo"));
				t.setCourseNo(resultSet.getString("Cno"));
				list.add(t);
			}
			System.out.println("ʵ�����װ���");
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<stuWithGrade> queryInsertGrade(String classNumber,String courseNumber) {
		String sql="select * from student s join sc b on s.Sno=b.Sno where s.SclassNo=? and b.Cno=?";
		Connection connection=getConnection();
		ArrayList<stuWithGrade> list=new ArrayList<stuWithGrade>();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,classNumber);
			preparedStatement.setString(2,courseNumber);
			resultSet=preparedStatement.executeQuery();
			System.out.println("��ѯ��ʦ���ڵĿγ̺Ϳ�Ŀ�ɹ�");
			while(resultSet.next()) {
				stuWithGrade s=new stuWithGrade();
				s.setStudentNum(resultSet.getString("Sno"));
				s.setStudentNameString(resultSet.getString("Sname"));
				s.setGrade(resultSet.getInt("grade")+"");
				s.setClassNumber(resultSet.getString("Cno"));
				System.out.println("ʵ�����װ���"+"----"+resultSet.getString("Sno")+"----"+resultSet.getString("Sname")+"----"+resultSet.getInt("grade")+"");
				list.add(s);
			}
			
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public boolean InsertGrade(String stuNumber,String classNumber,int grade) {
		String sql="update sc set grade=? where Sno=? and Cno=?";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setInt(1,grade);
			preparedStatement.setString(2,stuNumber);
			preparedStatement.setString(3,classNumber);
			if(preparedStatement.executeUpdate()==1) {
				System.out.println("����һ���˵Ŀ��Գɼ��ɹ�");
				return true;
			}else {
				System.out.println("����һ���˵Ŀ��Գɼ�ʧ��");
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	//��ѯһ�����ѧ���ĳɼ�
	public ArrayList<stuWithGrade> queryAllStuGrade (String classNo,String Cno) {
		String sql="select * from student s join sc b on s.Sno=b.Sno join course on b.Cno=Course.Cno where s.SclassNo=? and b.Cno=?";
		Connection connection=getConnection();
		ArrayList<stuWithGrade> list=new ArrayList<stuWithGrade>();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,classNo);
			preparedStatement.setString(2,Cno);
			resultSet=preparedStatement.executeQuery();
			System.out.println("��һ�����ѧ����ĳһ�ſγ̵ĳɼ��ɹ�");
			while(resultSet.next()) {
				stuWithGrade s=new stuWithGrade();
				s.setStudentNum(resultSet.getString("Sno"));
				s.setStudentNameString(resultSet.getString("Sname"));
				s.setGrade(resultSet.getInt("grade")+"");
				list.add(s);
			}
			System.out.println("ʵ�����װ���");
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	//������ʦ��ѯ�İ༶�Ż�ð༶��
	public String queryClassName (String classNo) {
		//type���ӵ�ǰ��Ҫ�ӿո�      Sno=���ʺ�ǰ�治Ҫ�пո�
		String sql="select * from class where ClassNo =?";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,classNo);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				return resultSet.getString("ClassName");
			}else {
				return "null";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "null";
	}
	//������ʦ��ѯ�İ༶�Ż�ÿγ���
	public String queryCourseName (String courseNo) {
		//type���ӵ�ǰ��Ҫ�ӿո�      Sno=���ʺ�ǰ�治Ҫ�пո�
		String sql="select * from course where Cno =?";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,courseNo);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next()) {
				return resultSet.getString("Cname");
			}else {
				return "null";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "null";
	}
	//����Ŀ�鿴������ܳɼ��ֲ�
	public ArrayList<displayByCourse> querydisplayByCourse (String Tno,String Cno) {
		String sql="select ClassName,avg(grade) as 'sum',count(*) as 'count' from sc b join  student s on s.Sno=b.Sno"
				+ " join class on SclassNo=ClassNo where SclassNo in (select ClassNo from teachInfo where Tno=? and Cno=?)\r\n" + 
				"and b.Cno=? group by ClassName";
		Connection connection=getConnection();
		ArrayList<displayByCourse> list=new ArrayList<displayByCourse>();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,Tno);
			preparedStatement.setString(2,Cno);
			preparedStatement.setString(3,Cno);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				displayByCourse d=new displayByCourse();
				d.setClassName(resultSet.getString("ClassName"));
				d.setSum(resultSet.getInt("sum"));
				d.setCount(resultSet.getInt("count"));
				list.add(d);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	//��ѯ����ѡ�޿ε���Ϣ
	public ArrayList<ElectiveCourse> queryElectiveCourse () {
		String sql="select * from course cou join teachInfo tea on cou.Cno=tea.Cno join teacher on tea.Tno=teacher.Tno where elective='ѡ��'";
		Connection connection=getConnection();
		ArrayList<ElectiveCourse> list=new ArrayList<ElectiveCourse>();
		try {
			preparedStatement =connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				ElectiveCourse e=new ElectiveCourse();
				e.setCno(resultSet.getString("Cno"));
				e.setCname(resultSet.getString("Cname"));
				e.setCredit(resultSet.getInt("Credit"));
				e.setClasstime(resultSet.getString("classTime"));
				e.setClassroom(resultSet.getString("classPlace"));
				e.setRemark(resultSet.getString("remarks"));
				e.setTname(resultSet.getString("Tname"));
				list.add(e);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	//����ѧ���Լ�ѡ�޵�ѡ�޿μ�¼
	public boolean chooseCourse(String sno,String cno) {
		Connection connection=getConnection();
		String sql="insert into sc(Sno,Cno) values (?,?)";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, sno);
			preparedStatement.setString(2, cno);
			if(preparedStatement.executeUpdate()==1) {
				System.out.println("��ͬѧ�Ѿ�ѡ�������ſ�"+cno);
				return true;
			}else {
				System.out.println("ѡ��ʧ��");
				return false;
			}
		} catch (SQLException e) {
			// TODO: handle exception
		}
		return false;
	}
	//ѧ����ѡ�Լ�ѡ�޵�ѡ�޿�
	public boolean withdrawCourse(String sno,String cno) {
		Connection connection=getConnection();
		String sql="delete from sc where Sno=? and Cno=?";
		try {
			preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setString(1, sno);
			preparedStatement.setString(2, cno);
			if(preparedStatement.executeUpdate()==1) {
				System.out.println("��ͬѧ�Ѿ���ѡ�����ſ�"+cno);
				return true;
			}else {
				System.out.println("��ѡʧ��");
				return false;
			}
		} catch (SQLException e) {
			// TODO: handle exception
		}
		return false;
	}
	//��ѯĳ�ſ�ĳ���಻�����ѧ��
	public ArrayList<FailByClass> queryStuFailByClass (String classNum,String subject,String tno) {
		String sql="select s.Sname,s.Sno,sc.grade,c.cno,c.Cname from student s join sc on s.Sno=sc.Sno join course c on c.Cno=sc.Cno where sc.Cno "
				+ "in (select Cno from teachInfo where Tno=? and Cno=? and s.SclassNo=?) and grade<60";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,tno);
			preparedStatement.setString(2, subject);
			preparedStatement.setString(3, classNum);
			resultSet=preparedStatement.executeQuery();
			ArrayList<FailByClass> list=new ArrayList<FailByClass>();
			while(resultSet.next()) {
				//һ����¼����Ϊһ���ɼ�������
				//Ϊ�ɼ��������ʼ��
				FailByClass fail=new FailByClass();
				fail.setSname(resultSet.getString("Sname"));
				fail.setSno(resultSet.getString("Sno"));
				fail.setGrade(resultSet.getInt("grade"));
				fail.setCno(resultSet.getString("Cno"));
				fail.setCname(resultSet.getString("Cname"));
				//�ѵ�ǰ�ĳɼ����������ӵ������б���
				list.add(fail);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	//��ѯĳ�಻��������
	public int queryFailNum(String classNum,String subject,String tno) {
		String sql="select count(1) as �ð಻�������� from student s join sc on s.Sno=sc.Sno join course c on c.Cno=sc.Cno where "
				+ "sc.Cno in (select Cno from teachInfo where Tno=? and Cno=? and s.SclassNo=?) and grade<60\r\n" + 
				"";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,tno);
			preparedStatement.setString(2, subject);
			preparedStatement.setString(3, classNum);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				//һ����¼����Ϊһ���ɼ�������
				//Ϊ�ɼ��������ʼ��
				//�ѵ�ǰ�ĳɼ����������ӵ������б���
				
				return resultSet.getInt("�ð಻��������");
			}
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	//��ѯĳ������
	public int queryClassNum(String classNum) {
		String sql="select ClassNumber from class where ClassNo=?";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,classNum);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				//һ����¼����Ϊһ���ɼ�������
				//Ϊ�ɼ��������ʼ��
				//�ѵ�ǰ�ĳɼ����������ӵ������б���
				
				return resultSet.getInt("ClassNumber");
			}
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	//��ѯȫ������Ŀγ�
	public int queryCourseNum() {
		String sql="select count(1) as ����γ���  from course";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				//һ����¼����Ϊһ���ɼ�������
				//Ϊ�ɼ��������ʼ��
				//�ѵ�ǰ�ĳɼ����������ӵ������б���
				return resultSet.getInt("����γ���");
			}
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	//��ѯ��ѧ�ڿ���Ŀγ�
	public int queryCurrCourseNum(String term) {
		String sql="select count(1) as ���� from course where Cno in (select distinct Cno from teachInfo where term=?)";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,term);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				//һ����¼����Ϊһ���ɼ�������
				//Ϊ�ɼ��������ʼ��
				//�ѵ�ǰ�ĳɼ����������ӵ������б���
				return resultSet.getInt("����");
			}
			return 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	//��ѯȫ���Ŀγ���
		public Vector<String> queryAllCourse(){
			String sql="select Cname from course)";
			Connection connection=getConnection();
			try {
				preparedStatement =connection.prepareStatement(sql);
				resultSet=preparedStatement.executeQuery();
				Vector<String> vector=new Vector<String>();
				while(resultSet.next()) {
					//һ����¼����Ϊһ���ɼ�������
					//Ϊ�ɼ��������ʼ��
					//�ѵ�ǰ�ĳɼ����������ӵ������б���
					vector.add(resultSet.getString("Cname"));
				}
				return vector;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
	//��ѯ��ѧ�ڵĿγ���
	public Vector<String> queryCurrCourse(String term){
		String sql="select Cname from course where Cno in (select distinct Cno from teachInfo where term=?)";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,term);
			resultSet=preparedStatement.executeQuery();
			Vector<String> vector=new Vector<String>();
			while(resultSet.next()) {
				//һ����¼����Ϊһ���ɼ�������
				//Ϊ�ɼ��������ʼ��
				//�ѵ�ǰ�ĳɼ����������ӵ������б���
				vector.add(resultSet.getString("Cname"));
			}
			return vector;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	//��ѯһ��ϵ�еİ༶�Ͷ�Ӧ�İ༶����
	public ArrayList<ClassNNN> queryClass(String depart){
		String sql="select * from class where Dno=?";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,depart);
			resultSet=preparedStatement.executeQuery();
			ArrayList<ClassNNN> list=new ArrayList<ClassNNN>();
			while(resultSet.next()) {
				ClassNNN classNNN=new ClassNNN();
				classNNN.setClassNo(resultSet.getString("ClassNo"));
				classNNN.setClassName(resultSet.getString("ClassName"));
				classNNN.setCapacity(resultSet.getInt("ClassNumber"));
				list.add(classNNN);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	//��ѯһ����Ӧ�ð��ŵĵ��ǻ�û�а��ŵĿ�-------ѧ����������Ϊ������̬��ѯ
	public ArrayList<Course> queryNonCourse(String classNo){
		String sql="select * from teachPlan join course on teachPlan.Cno=course.Cno where term='20171' and ClassNo=? and "
				+ " teachPlan.Cno not in (select Cno from teachInfo where teachInfo.ClassNo=?)";
		Connection connection=getConnection();
		try {
			preparedStatement =connection.prepareStatement(sql);
			preparedStatement.setString(1,classNo);
			preparedStatement.setString(2,classNo);
			resultSet=preparedStatement.executeQuery();
			ArrayList<Course> list=new ArrayList<Course>();
			while(resultSet.next()) {
				Course course=new Course();
				course.setCno(resultSet.getString("Cno"));
				course.setCname(resultSet.getString("Cname"));
				list.add(course);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	//��ѯһ�ſ��ڿε���ʦ
		public ArrayList<Teacher> queryTeacher(String departNo){
			String sql="select * from teacher where Dno=?";
			Connection connection=getConnection();
			try {
				preparedStatement =connection.prepareStatement(sql);
				preparedStatement.setString(1,departNo);
				resultSet=preparedStatement.executeQuery();
				ArrayList<Teacher> list=new ArrayList<Teacher>();
				while(resultSet.next()) {
					Teacher teacher=new Teacher();
					teacher.setTno(resultSet.getString("Tno"));
					teacher.setTname(resultSet.getString("Tname"));
					list.add(teacher);
				}
				return list;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
		//��ѯһ����ʦ�Ѿ����ſε�ʱ��
		public Vector<String> queryTime(String tno){
			String sql="select classTime from teachInfo where Tno=?";
			Connection connection=getConnection();
			try {
				preparedStatement =connection.prepareStatement(sql);
				preparedStatement.setString(1,tno);
				resultSet=preparedStatement.executeQuery();
				Vector<String> vector=new Vector<String>();
				while(resultSet.next()) {
					vector.add(resultSet.getString("classTime"));
				}
				return vector;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
		//��ѯһ��ʱ��û�пεĽ���
		public Vector<String> queryClassRoom(String time,int classNumber){
			String sql="select * from classroom where classPlace not in (select classPlace from teachInfo where classTime=?) and capacity>=?";
			Connection connection=getConnection();
			try {
				preparedStatement =connection.prepareStatement(sql);
				preparedStatement.setString(1,time);
				preparedStatement.setInt(2, classNumber);
				resultSet=preparedStatement.executeQuery();
				Vector<String> vector=new Vector<String>();
				while(resultSet.next()) {
					vector.add(resultSet.getString("classPlace"));
				}
				return vector;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
		//��ѯһ���������
		public int queryClassNumber(String classNo){
			String sql="select ClassNumber from class where ClassNo=?";
			Connection connection=getConnection();
			try {
				preparedStatement =connection.prepareStatement(sql);
				preparedStatement.setString(1,classNo);
				resultSet=preparedStatement.executeQuery();
				while(resultSet.next()) {
					return resultSet.getInt("ClassNumber");
				}
				return 0;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return 0;
		}
		//���ſγ�
		public boolean arrangeCourse(String classNo,String tno,String course,String time,String classroom){
			String sql="insert into teachInfo values (?,?,?,?,?,'�ޱ�ע����','20171')";
			Connection connection=getConnection();
			try {
				preparedStatement =connection.prepareStatement(sql);
				preparedStatement.setString(1,tno);
				preparedStatement.setString(2,course);
				preparedStatement.setString(3,classNo);
				preparedStatement.setString(4,time);
				preparedStatement.setString(5,classroom);
				if(preparedStatement.executeUpdate()==1){
					System.out.println("��γɹ�");
					return true;
				}
				return false;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}
}
