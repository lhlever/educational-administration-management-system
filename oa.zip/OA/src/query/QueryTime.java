package query;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Teacher;
import login.database;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class QueryTime
 */
public class QueryTime extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueryTime() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("test/json;charset=utf-8");
		PrintWriter writer =response.getWriter();
		String tno=request.getParameter("tno");
		database database=new database();
		Vector<String> vector=database.queryTime(tno);
		JSONArray array=new JSONArray();
		int result[][]=new int[8][5];
		for(int i=0;i<vector.size();i++) {
			result[vector.get(i).charAt(0)-'0'][vector.get(i).charAt(1)-'0']=1;
		}
		for(int i=1;i<=7;i++) {
			for(int j=1;j<=4;j++) {
				if(result[i][j]!=1) {
					JSONObject obj=new JSONObject();
					obj.put("availTime",i+(j+""));
					array.add(obj);
				}
			}
		}
		writer.print(array);
		writer.flush();
		writer.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
