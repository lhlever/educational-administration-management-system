package query;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.database;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class CourseProportion
 */
public class CourseProportion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CourseProportion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/plain;charset=utf-8");
		PrintWriter out=response.getWriter();
		database database=new database();
		Calendar now = Calendar.getInstance(); 
		String year=now.get(Calendar.YEAR)+""; 
		int month=now.get(Calendar.MONTH) + 1 ;
		if(month>=9||month<=1) {
			year=year+1;
		}else {
			year=year+2;
		}
		int allCourseNum=database.queryCourseNum();
		int currCourseNum=database.queryCurrCourseNum("20171");
		System.out.println("ȫ���γ�Ϊ"+allCourseNum);
		System.out.println("��ǰѧ�ڿγ�Ϊ"+currCourseNum);
		float currProper=((float)currCourseNum/allCourseNum);
		int proper=(int)(Float.parseFloat(String.format("%.2f", currProper))*100);
		int otherProper=100-currCourseNum;
		JSONObject object=new JSONObject();
		System.out.println(currProper);
		object.put("proper",proper+"");
		out.print(object);
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
