package query;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.FailByClass;
import entity.stuWithGrade;
import login.database;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class DisFailStuGrade
 */
public class DisFailStuGrade extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisFailStuGrade() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/json;charset=utf-8");
		PrintWriter out=response.getWriter();
		database database=new database();
		String classNumber=request.getParameter("classNumber");
		System.out.println("��̨��ȡ���İ༶��"+classNumber);
		String subject=request.getParameter("subject");
		System.out.println("��̨��ȡ���Ŀγ̺�"+subject);
		String tno=(String)request.getSession().getAttribute("username");
		JSONArray array=new JSONArray();
		JSONArray allArray=new JSONArray();
		JSONArray properArray =new JSONArray();
		JSONObject proJsonObject=new JSONObject();
		ArrayList<FailByClass> list=database.queryStuFailByClass(classNumber,subject,tno);
		for(int i=0;i<list.size();i++) {
			JSONObject obj=new JSONObject();
			obj.put("country",  list.get(i).getSname());
			obj.put("visits",  list.get(i).getGrade());
			array.add(obj);
		}
		allArray.add(0,array);
		System.out.println("��ѯĳ�಻��������---------"+database.queryFailNum(classNumber, subject, tno));
		System.out.println("����������Ϊ"+database.queryClassNum(classNumber));
		proJsonObject.put("propertion", Double.valueOf(database.queryFailNum(classNumber, subject, tno))/database.queryClassNum(classNumber));
		properArray.add(proJsonObject);
		allArray.add(1,properArray);
		out.print(allArray);
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
