package query;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.database;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class QueryClassRoom
 */
public class QueryClassRoom extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueryClassRoom() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("test/json;charset=utf-8");
		PrintWriter writer =response.getWriter();
		String time=request.getParameter("time");
		String classNo=request.getParameter("classNo");
		database database=new database();
		int classNumber=database.queryClassNumber(classNo);
		Vector<String> vector=database.queryClassRoom(time,classNumber);
		JSONArray array=new JSONArray();
		for(int i=0;i<vector.size();i++) {
			JSONObject obj=new JSONObject();
			obj.put("availRoom",vector.get(i));
			array.add(obj);
		}
		writer.print(array);
		writer.flush();
		writer.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
