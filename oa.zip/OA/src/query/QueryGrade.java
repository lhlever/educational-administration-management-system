package query;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.reportCard;
import login.database;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class QueryGrade
 */
public class QueryGrade extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueryGrade() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/json;charset=utf-8");
		PrintWriter out=response.getWriter();
		String objString=request.getParameter("time");
	
		//ȡ����ѧ����ֻ��1��2'1''2'
		int semester=objString.charAt(4)-'0';
		database database=new database();
		String username=(String)request.getSession().getAttribute("username");
//		�����ݿ��л�ȡ��ǰѧ������ѧʱ�䣨year-month-date��
		String year=database.queryYear(username, "student");
		//ȡ����ʱ���ǰ��λ����ת��������
//		Ȼ���ô���������ݼ�ȥ��ѧ�����
//		substringǰ�պ�
	
		int yearNum=Integer.parseInt(year.substring(0, 4));
//		��������ǵ�ǰѧ�����ڵ�ѧ���Ƕ��٣�1��2��3��4��5��6��7��8��
		int temp=(Integer.parseInt(objString.substring(0, 4))-yearNum)*2+semester;
		ArrayList<reportCard> List=database.queryStuGrade(username, temp);
		JSONArray array=new JSONArray();
		if(List!=null){
			for(int i=0;i<List.size();i++){
				JSONObject obj=new JSONObject();
				obj.put("Cno", List.get(i).getCno());
				obj.put("Cname",  List.get(i).getCname());
				obj.put("Credit",List.get(i).getCredit());
				obj.put("Grade",List.get(i).getGrade());
				array.add(i, obj);
			}
			System.out.println(array);
		}
		out.print(array);
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
