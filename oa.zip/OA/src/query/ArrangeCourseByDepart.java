package query;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.ClassNNN;
import login.database;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class ArrangeCourseByDepart
 */
public class ArrangeCourseByDepart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ArrangeCourseByDepart() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("test/json;charset=utf-8");
		PrintWriter writer =response.getWriter();
		String depart=request.getParameter("depart");
		database database=new database();
		ArrayList<ClassNNN> list=database.queryClass(depart);
		JSONArray array=new JSONArray();
		for(int i=0;i<list.size();i++) {
			JSONObject obj=new JSONObject();
			obj.put("classNo",list.get(i).getClassNo());
			obj.put("className",list.get(i).getClassName());
			obj.put("classNumber",list.get(i).getCapacity());
			array.add(obj);
		}
		writer.print(array);
		writer.flush();
		writer.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
