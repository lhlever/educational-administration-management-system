package query;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.ElectiveCourse;
import entity.reportCard;
import login.database;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetElectCourse
 */
public class GetElectCourse extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetElectCourse() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/json;charset=utf-8");
		PrintWriter out=response.getWriter();
		database database=new database();
		ArrayList<ElectiveCourse> list=database.queryElectiveCourse();
		String username=(String)request.getSession().getAttribute("username");
		String[][] strings=database.queryStuClass (username,1);
		JSONArray array=new JSONArray();
		for(int i=0;i<list.size();i++) {
			JSONObject obj=new JSONObject();
			obj.put("cno", list.get(i).getCno());
			obj.put("cname", list.get(i).getCname());
			obj.put("credit", list.get(i).getCredit());
			obj.put("classtime", list.get(i).getClasstime());
			obj.put("classroom", list.get(i).getClassroom());
			obj.put("remark", list.get(i).getRemark());
			int week=list.get(i).getClasstime().charAt(0)-'0';
			int period=list.get(i).getClasstime().charAt(1)-'0';
			//�Զ�ά�����ʾ���ںͽ��������š���ά����������һ������˵�൱�����˹�ϣ�����ж�һ�ڿ��ǲ����п�ʱ������Ҫ�ٴ�Ƕ��ѭ�����ж϶�ά�����ǲ���Ϊ�վͿ���
			//�����ص���Ϣ�а����������Լ�
			CharSequence result=list.get(i).getCname();
			//||!strings[week][period].contains(result)
			if(strings[week][period]==""||strings[week][period]==null) {
				obj.put("clash","����ͻ");	
			}else if(strings[week][period].contains(result)){
				obj.put("clash","��ѡ");
			}else{
				obj.put("clash","����ѡ��"+'"'+strings[week][period]+'"'+"��ͻ");
			}
			obj.put("tname", list.get(i).getTname());
			array.add(obj);
		}
		out.print(array);
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
