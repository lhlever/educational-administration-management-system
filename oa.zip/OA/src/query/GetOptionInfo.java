package query;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.teachClassCourse;
import login.database;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class GetOptionInfo
 */
public class GetOptionInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetOptionInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/json;charset=utf-8");
		PrintWriter out=response.getWriter();
		System.out.println("���뵽��ѯ��ʦ���ڵĿ�Ŀ�Ͱ༶");
		database database=new database();
		String username=(String)request.getSession().getAttribute("username");
		ArrayList<teachClassCourse> list=database.queryTeachClassCourse(username);
		JSONArray array=new JSONArray();
		for(int i=0;i<list.size();i++) {
			JSONObject obj=new JSONObject();
			obj.put("className", list.get(i).getClassName());
			obj.put("courseName", list.get(i).getCourse());
			obj.put("classNumber", list.get(i).getClassNo());
			obj.put("courseNumber", list.get(i).getCourseNo());
			array.add(obj);
		}
		System.out.println(array);
		out.print(array);
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
