package query;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import login.database;

/**
 * Servlet implementation class teacherQuery
 */
public class teacherQuery extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public teacherQuery() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//��ȡ������Ĳ�ѯ����
				String type=request.getParameter("type");
				System.out.println("�������Ĳ�����"+type);
				if("classTable".equals(type)) {
					System.out.println("��ʦ���뵽��ѯ�γ̱�");
					String objString=request.getParameter("time1");
					//�������ݿ����
					database database=new database();
					//��ȡsession�е��û���
					String username=(String)request.getSession().getAttribute("username");
					//�����ݿ��л�ȡ��ǰѧ������ѧʱ�䣨year-month-date��
					//�����������
					request.setAttribute("classTable", database.queryTeacherClass(username, objString));
					//ת��
					request.getRequestDispatcher("teacher/firstPage.jsp").forward(request, response);
				}
				if("insertGrade".equals(type)) {
					System.out.println("��ʦ���뵽¼��ɼ�");
					database database=new database();
					String classNumber=request.getParameter("classNumber");
					String subject=request.getParameter("subject");
					System.out.println("�༶����"+classNumber+"��Ŀ��"+subject);
					request.setAttribute("stuGrade", database.queryInsertGrade(classNumber, subject));
					request.getRequestDispatcher("teacher/firstPage.jsp").forward(request, response);
				}
				if("getClass".equals(type)) {
					System.out.println("���뵽��ѯ��ʦ���ڵĿ�Ŀ�Ͱ༶");
					database database=new database();
					String username=(String)request.getSession().getAttribute("username");
					request.setAttribute("classCourse", database.queryTeachClassCourse(username));
					request.getRequestDispatcher("teacher/firstPage.jsp").forward(request, response);
				}
				if("display".equals(type)) {
					System.out.println("���뵽��ѯ��ʦ���ڵĿ�Ŀ�Ͱ༶");
					database database=new database();
					String username=(String)request.getSession().getAttribute("username");
					request.setAttribute("display", database.queryTeachClassCourse(username));
					request.getRequestDispatcher("teacher/firstPage.jsp").forward(request, response);
				}
				if("save".equals(type)) {
					database database=new database();
					int size=Integer.parseInt(request.getParameter("size"));
					for(int i=0;i<size;i++) {
						String Sno=request.getParameter("Sno"+i);
						String Cno=request.getParameter("Cno"+i);
						int grade=Integer.parseInt(request.getParameter("grade"+i));
						System.out.print("ѧ��Ϊ"+Sno+"�γ̺�Ϊ"+Cno+"����Ϊ"+grade);
						if(database.InsertGrade(Sno, Cno, grade)) {
							System.out.println("-----------���ͬѧ�ĳɼ��Ѿ������浽���ݿ��У�����׼��������һ��----------------");
						}
					}
					request.getRequestDispatcher("teacher/firstPage.jsp").forward(request, response);
				}
				if("disGrade".equals(type)) {
					database database=new database();
					String classNumber=request.getParameter("classNumber");
					String subject=request.getParameter("subject");
//					System.out.println("�༶����"+classNumber+"��Ŀ��"+subject);
					request.setAttribute("title", database.queryClassName(classNumber)+database.queryCourseName(subject)+"���˷����ֲ�ͼ");
					request.setAttribute("disp", database.queryAllStuGrade(classNumber, subject));
					request.getRequestDispatcher("teacher/firstPage.jsp").forward(request, response);
				}
				if("disaAllClass".equals(type)) {
					database database=new database();
//					String classNumber=request.getParameter("classNumber");
					String subject=request.getParameter("subject");
					String Tno=(String)request.getSession().getAttribute("username");
					request.setAttribute("title",database.queryCourseName(subject)+"��������ֲ�ͼ");
					request.setAttribute("displ", database.querydisplayByCourse(Tno, subject));
					request.getRequestDispatcher("teacher/firstPage.jsp").forward(request, response);
				}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
