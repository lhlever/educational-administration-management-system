package query;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.displayByCourse;
import login.database;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Servlet implementation class DisBySubject
 */
public class DisBySubject extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisBySubject() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/json;charset=utf-8");
		PrintWriter out=response.getWriter();
		String tno=(String)request.getSession().getAttribute("username");
		String subject=request.getParameter("subject");
		database database=new database();
		ArrayList<displayByCourse> list=database.querydisplayByCourse(tno, subject);
		//ע��array�������򣬲��ܷ���if����
		JSONArray array=new JSONArray();
		for(int i=0;i<list.size();i++){
			JSONObject obj=new JSONObject();
			//�����
			obj.put("subject",  list.get(i).getClassName());
			obj.put("sum", list.get(i).getSum()+"");
			array.add(i, obj);
		}
		System.out.println(array);
		out.print(array);
		out.flush();
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
